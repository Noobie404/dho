<?php echo $__env->make('layouts.master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section id="banner">
  <div class="banner-back img-fluid">
    <img src="<?php echo asset('master/img/Path2736.svg'); ?>" alt="">
  </div>
  <div class="banner-content">
    <div class="row">
      <div class="col-md-7">
        <div class="banner-text">
          <h2>We Offer World's Best Domain Hosting Deals.</h2>
          <div class="banner-buttons">


            <a href="<?php echo e(route('DomainOffer')); ?>" class="banner-button-1"> Domain Offers</a>
            <a href="<?php echo e(route('HostingOffer')); ?>" class="banner-button-2"> Hosting Offers</a>
          </div>
        </div>
      </div>
      <div class="col-md-5">
        <div class="banner-img img-fluid">
          <img class="d-sm-none d-md-block" src="<?php echo asset('master/img/Group 527.svg'); ?>" alt="">

        </div>
      </div>
    </div>
  </div>
</section>
<section id="offers">
  <!-- <div class="offers-back-img">
    <img class="img-fluid" src="<?php echo asset('master/img/Group 870.svg'); ?>" alt="">

  </div> -->
  <div class="offer-header">
    <h1>Exclusive Offers</h1>
  </div>
  <div class="offers-card">

    <div class="container">

      <div class="row">
        <div id="owl-demo" class="owl-carousel owl-theme">
        <?php $__currentLoopData = $exlusive_offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exclusive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <div class="row">
                <div class="col-sm-3">
                  <?php if($exclusive->product_cat == 'Domain'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/world-wide-web.svg'); ?>" alt="">
                  <?php elseif($exclusive->product_cat == 'Hosting'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/server.svg'); ?>" alt="">
                  <?php elseif($exclusive->product_cat == 'Combo'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/icon.svg'); ?>" alt="">
                  <?php else: ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/server(1).svg'); ?>" alt="">
                  <?php endif; ?>
                </div>
                <div class="col-sm-6">
                  <h3>
                    <?php echo e($exclusive->product_cat); ?> Offer
                    
                    <br><span> <?php echo e($exclusive->title); ?> only <?php echo e($exclusive->price); ?> <?php echo e($exclusive->currency); ?> </span></h3>
                </div>
                <div class="col-sm-3" style="padding-right: 10px;">
                  <h4><span class="dot"></span> Active</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tldname">
                <h2><?php echo e($exclusive->title); ?></h2>
                <h3><?php echo e(str_replace("~", "", $exclusive->sub_title)); ?></h3>
              </div>
              <div class="provider-name">
                <h3>Provider Name:<span> <?php echo e($exclusive->provider); ?></span></h3>
              </div><br>
              <?php if($exclusive->promo_code != null): ?>
              <div class="offer-link">
                <a data-toggle="modal" data-target="#exampleModal" id="modal-open" onclick="modal_open(<?php echo e($exclusive->id); ?>)" data-whatever="@mdo" href="javascript:void(0)">Get Your Promo Code</a>
              </div>
              <?php endif; ?>
              <br>
              <div class="offer-validity">
                <h4>Offer Validity:</h4>
                <div class="offer-time">
                  <div class="row">
                    <div class="col-sm-5">
                      <div class="time-start">
                        <?php  $format = ('d M, y');

                            $start_date = date($format, strtotime($exclusive->offer_start));
                            $end_date = date($format, strtotime($exclusive->offer_end));
                        ?>
                        <h4>Start Date<br><span><?php echo e($start_date); ?></span></h4>
                        <span class="line"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="time-end">


                        <h4>End Date<br><span><?php echo e($end_date); ?></span></h4>

                      </div>
                    </div>

                  </div>
                  <div class="offer-note">
                    <h4>Note : <?php echo e($exclusive->offer_note); ?></h4>

                  </div>
                </div>

              </div>
              <div class="deal-section">
                <h4>Deal Price:</h4>
                <div class="deal-price">
                  <h2> <span class="currency-symbol"><?php echo e($exclusive->currency == "BDT" ? "৳" : "$"); ?></span><?php echo e($exclusive->price); ?> <span class="currency"><?php echo e($exclusive->currency == "BDT" ? "TK" : "USD"); ?></span> </h2>
                </div>
              </div>
              <div class="card-buttons">
                <div class="row">
                  <div class="col-sm-7">
                    <?php if($exclusive->promo_code != null): ?>
                    <a data-toggle="modal" data-target="#exampleModal"id="modal-open" onclick="modal_open(<?php echo e($exclusive->id); ?>)" data-whatever="@mdo" class="card-order" href="javascript:void(0)"> Order Now </a>
                    <?php else: ?>
                    <a  href="<?php echo e($exclusive->affiliate_link); ?>" target="_blank" class="card-order"> Order Now </a>
                    <?php endif; ?>
                  </div>
                  <a style="display: hidden" id="order-now-<?php echo e($exclusive->id); ?>" href="<?php echo e($exclusive->affiliate_link); ?>" target="_blank"></a>
                  <div class="col-sm-5">
                    <a class="card-details" data-toggle="modal" data-target="#exampleModalMore" id="modal-open"  href="javascript:void(0)" onclick="open_details(<?php echo e($exclusive->id); ?>)"> More Details </a>                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
  </div>
  <div class="offer-button">
    <a href="<?php echo e(route('AllExclusiveOffer')); ?>">More Exclusive Offers</a>
  </div>
</section>
<section id="special-offers">
  <!-- <div class="offers-back-img">
    <img class="img-fluid" src="<?php echo asset('master/img/Group 870.svg'); ?>" alt="">

  </div> -->
  <div class="offer-header">
    <h1>Special Offers</h1>
  </div>
  <div class="offers-card">

    <div class="container">
      <div class="row">
        <div id="owl-demo" class="owl-carousel owl-theme">
      <?php $__currentLoopData = $special_offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $special): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <div class="row">
                <div class="col-sm-3">
                  <?php if($special->product_cat == 'Domain'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/world-wide-web.svg'); ?>" alt="">
                  <?php elseif($special->product_cat == 'Hosting'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/server.svg'); ?>" alt="">
                  <?php elseif($special->product_cat == 'Combo'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/icon.svg'); ?>" alt="">
                  <?php else: ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/server(1).svg'); ?>" alt="">
                  <?php endif; ?>
                </div>
                <div class="col-sm-6">
                  <h3>
                    <?php echo e($special->product_cat); ?> Offer
                    <br><span> <?php echo e($special->title); ?> only <?php echo e($special->price); ?> <?php echo e($special->currency); ?> </span></h3>
                </div>
                <div class="col-sm-3"  style="padding-right: 10px;">
                  <h4><span class="dot"></span> Active</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tldname">
                <h2><?php echo e($special->title); ?></h2>
                <h3><?php echo e(str_replace("~", "", $special->sub_title)); ?></h3>
              </div>
              <div class="provider-name">
                <h3>Provider Name:<span> <?php echo e($special->provider); ?></span></h3>
              </div><br>
              <?php if($special->promo_code != null): ?>
              <div class="offer-link">
                <a data-toggle="modal" data-target="#exampleModal" id="modal-open" onclick="modal_open(<?php echo e($special->id); ?>)" data-whatever="@mdo" href="javascript:void(0)">Get Your Promo Code</a>
              </div>
              <?php endif; ?>
              <br>
              <div class="offer-validity">
                <h4>Offer Validity:</h4>
                <div class="offer-time">
                  <div class="row">
                    <div class="col-sm-5">
                      <div class="time-start">
                        <?php  $format = ('d M, y');

                            $start_date = date($format, strtotime($special->offer_start));
                            $end_date = date($format, strtotime($special->offer_end));
                        ?>
                        <h4>Start Date<br><span><?php echo e($start_date); ?></span></h4>
                        <span class="line"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="time-end">


                        <h4>End Date<br><span><?php echo e($end_date); ?></span></h4>

                      </div>
                    </div>

                  </div>
                  <div class="offer-note">
                    <h4>Note : <?php echo e($special->offer_note); ?></h4>

                  </div>
                </div>

              </div>
              <div class="deal-section">
                <h4>Deal Price:</h4>
                <div class="deal-price">
                  <h2> <span class="currency-symbol"><?php echo e($special->currency == "BDT" ? "৳" : "$"); ?></span><?php echo e($special->price); ?> <span class="currency"><?php echo e($special->currency == "BDT" ? "TK" : "USD"); ?></span> </h2>
                </div>
              </div>
              <div class="card-buttons">
                <div class="row">
                  <div class="col-sm-7">
                    <?php if($special->promo_code != null): ?>
                    <a data-toggle="modal" data-target="#exampleModal"id="modal-open" onclick="modal_open(<?php echo e($special->id); ?>)" data-whatever="@mdo" class="card-order" href="javascript:void(0)"> Order Now </a>
                    <?php else: ?>
                    <a  href="<?php echo e($special->affiliate_link); ?>" target="_blank" class="card-order"> Order Now </a>
                    <?php endif; ?>
                  </div>
                  <a style="display: hidden" id="order-now-<?php echo e($special->id); ?>" href="<?php echo e($special->affiliate_link); ?>" target="_blank"></a>
                  <div class="col-sm-5">
                    <a class="card-details" data-toggle="modal" data-target="#exampleModalMore" id="modal-open"  href="javascript:void(0)" onclick="open_details(<?php echo e($special->id); ?>)"> More Details </a>                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
  <div class="offer-button">
    <a href="<?php echo e(route('AllSpecialOffer')); ?>">More Special Offers</a>
  </div>
</section>
<section id="regular-offers">
  <!-- <div class="offers-back-img">
    <img class="img-fluid" src="<?php echo asset('master/img/Group 870.svg'); ?>" alt="">
  </div> -->
  <div class="offer-header">
    <h1>Regular Offers</h1>
  </div>
  <div class="offers-card">
    <div class="container">
      <div class="row">
        <div id="owl-demo" class="owl-carousel owl-theme">
      <?php $__currentLoopData = $regular_offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <div class="row">
                <div class="col-sm-3">
                  <?php if($regular->product_cat == 'Domain'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/world-wide-web.svg'); ?>" alt="">
                  <?php elseif($regular->product_cat == 'Hosting'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/server.svg'); ?>" alt="">
                  <?php elseif($regular->product_cat == 'Combo'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/icon.svg'); ?>" alt="">
                  <?php else: ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/server(1).svg'); ?>" alt="">
                  <?php endif; ?>
                </div>
                <div class="col-sm-6">
                  <h3>
                    <?php echo e($regular->product_cat); ?> Offer
                    
                    <br><span> <?php echo e($regular->title); ?> only <?php echo e($regular->price); ?> <?php echo e($regular->currency); ?> </span></h3>
                </div>
                <div class="col-sm-3"  style="padding-right: 10px;">
                  <h4><span class="dot"></span> Active</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tldname">
                <h2><?php echo e($regular->title); ?></h2>
                <h3><?php echo e(str_replace("~", "", $regular->sub_title)); ?></h3>
              </div>
              <div class="provider-name">
                <h3>Provider Name:<span> <?php echo e($regular->provider); ?></span></h3>
              </div><br>
              <?php if($regular->promo_code != null): ?>
              <div class="offer-link">
                <a data-toggle="modal" data-target="#exampleModal" id="modal-open" onclick="modal_open(<?php echo e($regular->id); ?>)" data-whatever="@mdo" href="javascript:void(0)">Get Your Promo Code</a>
              </div>
              <?php endif; ?>
              <br>
              <div class="offer-validity">
                <h4>Offer Validity:</h4>
                <div class="offer-time">
                  <div class="row">
                    <div class="col-sm-5">
                      <div class="time-start">
                        <?php  $format = ('d M, y');

                            $start_date = date($format, strtotime($regular->offer_start));
                            $end_date = date($format, strtotime($regular->offer_end));
                        ?>
                        <h4>Start Date<br><span><?php echo e($start_date); ?></span></h4>
                        <span class="line"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="time-end">


                        <h4>End Date<br><span><?php echo e($end_date); ?></span></h4>

                      </div>
                    </div>

                  </div>
                  <div class="offer-note">
                    <h4>Note : <?php echo e($regular->offer_note); ?></h4>

                  </div>
                </div>

              </div>
              <div class="deal-section">
                <h4>Deal Price:</h4>
                <div class="deal-price">
                  <h2> <span class="currency-symbol"><?php echo e($regular->currency == "BDT" ? "৳" : "$"); ?></span><?php echo e($regular->price); ?> <span class="currency"><?php echo e($regular->currency == "BDT" ? "TK" : "USD"); ?></span> </h2>
                </div>
              </div>
              <div class="card-buttons">
                <div class="row">
                  <div class="col-sm-7">
                    <?php if($regular->promo_code != null): ?>
                    <a data-toggle="modal" data-target="#exampleModal"id="modal-open" onclick="modal_open(<?php echo e($regular->id); ?>)" data-whatever="@mdo" class="card-order" href="javascript:void(0)"> Order Now </a>
                    <?php else: ?>
                    <a  href="<?php echo e($regular->affiliate_link); ?>" target="_blank" class="card-order"> Order Now </a>
                    <?php endif; ?>
                  </div>
                  <a style="display: hidden" id="order-now-<?php echo e($regular->id); ?>" href="<?php echo e($regular->affiliate_link); ?>" target="_blank"></a>
                  <div class="col-sm-5">
                    <a class="card-details" data-toggle="modal" data-target="#exampleModalMore" id="modal-open"  href="javascript:void(0)" onclick="open_details(<?php echo e($regular->id); ?>)"> More Details </a>                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
  <div class="offer-button mb-4">
    <a href="<?php echo e(route('AllRegularOffer')); ?>">More Regular Offers</a>
  </div>
</section>

<?php echo $__env->make('layouts.master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>