<?php echo $__env->make('layouts.master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<section id="banner">
  <div class="banner-back img-fluid">
    <img src="<?php echo asset('master/img/Path2736.svg'); ?>" alt="">
  </div>
  <div class="banner-content">


    <div class="row">



      <div class="col-md-7">
        <div class="banner-text">
          <h2>We Offer World's Best Domain Hosting Deals.</h2>
          <div class="banner-buttons">


            <a href="<?php echo e(route('DomainOffer')); ?>" class="banner-button-1"> Domain Offers</a>
            <a href="<?php echo e(route('HostingOffer')); ?>" class="banner-button-2"> Hosting Offers</a>
          </div>
        </div>
      </div>
      <div class="col-md-5">
        <div class="banner-img img-fluid">
          <img class="d-sm-none d-md-block" src="<?php echo asset('master/img/Group 527.svg'); ?>" alt="">

        </div>
      </div>
    </div>
  </div>
</section>
<section id="offers">
  <!-- <div class="offers-back-img">
    <img class="img-fluid" src="<?php echo asset('master/img/Group 870.svg'); ?>" alt="">

  </div> -->
  <div class="offer-header">
    <h1>Exclusive Offers</h1>
  </div>
  <div class="offers-card">

    <div class="container">

      <div class="row">
      <?php $__currentLoopData = $dataSet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exclusive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <div class="card">
            <div class="card-header">
              <div class="row">
                <div class="col-sm-3">
                  <?php if($exclusive->product_cat == 'Domain'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/world-wide-web.svg'); ?>" alt="">
                  <?php elseif($exclusive->product_cat == 'Hosting'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/server.svg'); ?>" alt="">
                  <?php elseif($exclusive->product_cat == 'Combo'): ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/icon.svg'); ?>" alt="">
                  <?php else: ?>
                  <img class="img-fluid" src="<?php echo asset('master/img/server(1).svg'); ?>" alt="">
                  <?php endif; ?>
                </div>
                <div class="col-sm-6">
                  <h3>
                    <?php if($exclusive->product_cat == 'Domain'): ?>
                    Domain Offer 
                    <?php elseif($exclusive->product_cat == 'Hosting'): ?>
                    Hosting Offer 
                    <?php elseif($exclusive->product_cat == 'Combo'): ?>
                    Combo Offer
                    <?php else: ?>
                    Web-Server Offer
                    <?php endif; ?>
                    
                    <br><span> <?php echo e($exclusive->title); ?> only <?php echo e($exclusive->price); ?> <?php echo e($exclusive->currency); ?> </span></h3>
                </div>
                <div class="col-sm-3">
                  <h4><span class="dot"></span> Active</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tldname">
                <h2><?php echo e($exclusive->title); ?></h2>
                <h3><?php echo e($exclusive->sub_title); ?></h3>
              </div>
              <div class="provider-name">
                <h3>Provider Name:<span> <?php echo e($exclusive->provider); ?></span></h3>
              </div><br>
              <div class="offer-link">
                <a data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" href="javascript:void(0)">Get Your Promo Code</a>

              </div><br>
              <div class="offer-validity">
                <h4>Offer Validity:</h4>
                <div class="offer-time">
                  <div class="row">
                    <div class="col-sm-5">
                      <div class="time-start">
                        <?php  $format = ('d M, y');

                            $start_date = date($format, strtotime($exclusive->offer_start));
                            $end_date = date($format, strtotime($exclusive->offer_end));
                        ?>
                        <h4>Start Date<br><span><?php echo e($start_date); ?></span></h4>
                        <span class="line"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="time-end">


                        <h4>End Date<br><span><?php echo e($end_date); ?></span></h4>

                      </div>
                    </div>

                  </div>
                  <div class="offer-note">
                    <h4>Note : <?php echo e($exclusive->offer_note); ?></h4>

                  </div>
                </div>

              </div>
              <div class="deal-section">
                <h4>Deal Price:</h4>
                <div class="deal-price">
                  <h2> <span class="currency-symbol"><?php echo e($exclusive->currency == "BDT" ? "৳" : "$"); ?></span><?php echo e($exclusive->price); ?> <span class="currency"><?php echo e($exclusive->currency == "BDT" ? "TK" : "USD"); ?></span> </h2>
                </div>
              </div>
              <div class="card-buttons">
                <div class="row">
                  <div class="col-sm-7">
                    <a class="card-order" href="<?php echo e($exclusive->affiliate_link); ?> target:"_blank"> Order Now </a>
                  </div>
                  <div class="col-sm-5">
                    <a class="card-details" href="#"> More Details </a>
                  </div>
                </div>


              </div>
            </div>
          </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <div class="offer-button">
    <a href="#">More Exclusive Offers</a>
  </div>
</section>
<section id="special-offers">
  <!-- <div class="offers-back-img">
    <img class="img-fluid" src="<?php echo asset('master/img/Group 870.svg'); ?>" alt="">

  </div> -->
  <div class="offer-header">
    <h1>Special Offers</h1>
  </div>
  <div class="offers-card">


    <div class="container">

      <div class="row">

        <div class="col-md-4">
          <div class="card">
            <div class="card-header">
              <div class="row">


                <div class="col-sm-3">
                  <img class="img-fluid" src="<?php echo asset('master/img/world-wide-web.svg'); ?>" alt="">
                </div>
                <div class="col-sm-6">
                  <h3>Domain Offer <br><span> .com only 499 BDT </span></h3>
                </div>
                <div class="col-sm-3">
                  <h4><span class="dot"></span> Active</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tldname">
                <h2>.COM</h2>
                <h3>.com is a TLD</h3>
              </div>
              <div class="provider-name">
                <h3>Provider Name:<span> VaneHost</span></h3>
              </div><br>
              <div class="offer-link">
                <a data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" href="#">Get Your Promo Code</a>

              </div><br>
              <div class="offer-validity">
                <h4>Offer Validity:</h4>
                <div class="offer-time">
                  <div class="row">
                    <div class="col-sm-5">
                      <div class="time-start">


                        <h4>Start Date<br><span>01 July 19</span></h4>
                        <span class="line"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="time-end">


                        <h4>End Date<br><span>01 Nov 19</span></h4>

                      </div>
                    </div>

                  </div>
                  <div class="offer-note">
                    <h4>Note : You can get this offer until end date.</h4>

                  </div>
                </div>

              </div>
              <div class="deal-section">
                <h4>Deal Price:</h4>
                <div class="deal-price">
                  <h2> <span class="currency-symbol">৳</span>4999 <span class="currency">TK</span> </h2>

                </div>
              </div>
              <div class="card-buttons">
                <div class="row">
                  <div class="col-sm-7">
                    <a class="card-order" href="#"> Order Now </a>
                  </div>
                  <div class="col-sm-5">
                    <a class="card-details" href="#"> More Details </a>
                  </div>
                </div>


              </div>
            </div>
          </div>

        </div>
        <div class="col-md-4">
          <div class="card">
            <div class="card-header">
              <div class="row">


                <div class="col-sm-3">
                  <img class="img-fluid" src="<?php echo asset('master/img/world-wide-web.svg'); ?>" alt="">
                </div>
                <div class="col-sm-6">
                  <h3>Domain Offer <br><span> .com only 499 BDT </span></h3>
                </div>
                <div class="col-sm-3">
                  <h4><span class="dot"></span> Active</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tldname">
                <h2>.COM</h2>
                <h3>.com is a TLD</h3>
              </div>
              <div class="provider-name">
                <h3>Provider Name:<span> VaneHost</span></h3>
              </div><br>
              <div class="offer-link">
                <a data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" href="#">Get Your Promo Code</a>

              </div><br>
              <div class="offer-validity">
                <h4>Offer Validity:</h4>
                <div class="offer-time">
                  <div class="row">
                    <div class="col-sm-5">
                      <div class="time-start">


                        <h4>Start Date<br><span>01 July 19</span></h4>
                        <span class="line"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="time-end">


                        <h4>End Date<br><span>01 Nov 19</span></h4>

                      </div>
                    </div>

                  </div>
                  <div class="offer-note">
                    <h4>Note : You can get this offer until end date.</h4>

                  </div>
                </div>

              </div>
              <div class="deal-section">
                <h4>Deal Price:</h4>
                <div class="deal-price">
                  <h2> <span class="currency-symbol">৳</span>4999 <span class="currency">TK</span> </h2>

                </div>
              </div>
              <div class="card-buttons">
                <div class="row">
                  <div class="col-sm-7">
                    <a class="card-order" href="#"> Order Now </a>
                  </div>
                  <div class="col-sm-5">
                    <a class="card-details" href="#"> More Details </a>
                  </div>
                </div>


              </div>
            </div>

          </div>
        </div>
        <div class="col-md-4">
          <div class="card">
            <div class="card-header">
              <div class="row">


                <div class="col-sm-3">
                  <img class="img-fluid" src="<?php echo asset('master/img/world-wide-web.svg'); ?>" alt="">
                </div>
                <div class="col-sm-6">
                  <h3>Domain Offer <br><span> .com only 499 BDT </span></h3>
                </div>
                <div class="col-sm-3">
                  <h4><span class="dot"></span> Active</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tldname">
                <h2>.COM</h2>
                <h3>.com is a TLD</h3>
              </div>
              <div class="provider-name">
                <h3>Provider Name:<span> VaneHost</span></h3>
              </div><br>
              <div class="offer-link">
                <a data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" href="#">Get Your Promo Code</a>

              </div><br>
              <div class="offer-validity">
                <h4>Offer Validity:</h4>
                <div class="offer-time">
                  <div class="row">
                    <div class="col-sm-5">
                      <div class="time-start">


                        <h4>Start Date<br><span>01 July 19</span></h4>
                        <span class="line"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="time-end">


                        <h4>End Date<br><span>01 Nov 19</span></h4>

                      </div>
                    </div>

                  </div>
                  <div class="offer-note">
                    <h4>Note : You can get this offer until end date.</h4>

                  </div>
                </div>

              </div>
              <div class="deal-section">
                <h4>Deal Price:</h4>
                <div class="deal-price">
                  <h2> <span class="currency-symbol">৳</span>4999 <span class="currency">TK</span> </h2>

                </div>
              </div>
              <div class="card-buttons">
                <div class="row">
                  <div class="col-sm-7">
                    <a class="card-order" href="#"> Order Now </a>
                  </div>
                  <div class="col-sm-5">
                    <a class="card-details" href="#"> More Details </a>
                  </div>
                </div>


              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  </div>
  <div class="offer-button">
    <a href="#">More Special Offers</a>
  </div>
</section>
<section id="regular-offers">
  <!-- <div class="offers-back-img">
    <img class="img-fluid" src="<?php echo asset('master/img/Group 870.svg'); ?>" alt="">

  </div> -->
  <div class="offer-header">
    <h1>Regular Offers</h1>
  </div>
  <div class="offers-card">


    <div class="container">

      <div class="row">

        <div class="col-md-4">
          <div class="card">
            <div class="card-header">
              <div class="row">


                <div class="col-sm-3">
                  <img class="img-fluid" src="<?php echo asset('master/img/world-wide-web.svg'); ?>" alt="">
                </div>
                <div class="col-sm-6">
                  <h3>Domain Offer <br><span> .com only 499 BDT </span></h3>
                </div>
                <div class="col-sm-3">
                  <h4><span class="dot"></span> Active</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tldname">
                <h2>.COM</h2>
                <h3>.com is a TLD</h3>
              </div>
              <div class="provider-name">
                <h3>Provider Name:<span> VaneHost</span></h3>
              </div><br>
              <div class="offer-link">
                <a data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" href="#">Get Your Promo Code</a>

              </div><br>
              <div class="offer-validity">
                <h4>Offer Validity:</h4>
                <div class="offer-time">
                  <div class="row">
                    <div class="col-sm-5">
                      <div class="time-start">


                        <h4>Start Date<br><span>01 July 19</span></h4>
                        <span class="line"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="time-end">


                        <h4>End Date<br><span>01 Nov 19</span></h4>

                      </div>
                    </div>

                  </div>
                  <div class="offer-note">
                    <h4>Note : You can get this offer until end date.</h4>

                  </div>
                </div>

              </div>
              <div class="deal-section">
                <h4>Deal Price:</h4>
                <div class="deal-price">
                  <h2> <span class="currency-symbol">৳</span>4999 <span class="currency">TK</span> </h2>

                </div>
              </div>
              <div class="card-buttons">
                <div class="row">
                  <div class="col-sm-7">
                    <a class="card-order" href="#"> Order Now </a>
                  </div>
                  <div class="col-sm-5">
                    <a class="card-details" href="#"> More Details </a>
                  </div>
                </div>


              </div>
            </div>
          </div>

        </div>
        <div class="col-md-4">
          <div class="card">
            <div class="card-header">
              <div class="row">


                <div class="col-sm-3">
                  <img class="img-fluid" src="<?php echo asset('master/img/world-wide-web.svg'); ?>" alt="">
                </div>
                <div class="col-sm-6">
                  <h3>Domain Offer <br><span> .com only 499 BDT </span></h3>
                </div>
                <div class="col-sm-3">
                  <h4><span class="dot"></span> Active</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tldname">
                <h2>.COM</h2>
                <h3>.com is a TLD</h3>
              </div>
              <div class="provider-name">
                <h3>Provider Name:<span> VaneHost</span></h3>
              </div><br>
              <div class="offer-link">
                <a data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" href="#">Get Your Promo Code</a>

              </div><br>
              <div class="offer-validity">
                <h4>Offer Validity:</h4>
                <div class="offer-time">
                  <div class="row">
                    <div class="col-sm-5">
                      <div class="time-start">


                        <h4>Start Date<br><span>01 July 19</span></h4>
                        <span class="line"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="time-end">


                        <h4>End Date<br><span>01 Nov 19</span></h4>

                      </div>
                    </div>

                  </div>
                  <div class="offer-note">
                    <h4>Note : You can get this offer until end date.</h4>

                  </div>
                </div>

              </div>
              <div class="deal-section">
                <h4>Deal Price:</h4>
                <div class="deal-price">
                  <h2> <span class="currency-symbol">৳</span>4999 <span class="currency">TK</span> </h2>

                </div>
              </div>
              <div class="card-buttons">
                <div class="row">
                  <div class="col-sm-7">
                    <a class="card-order" href="#"> Order Now </a>
                  </div>
                  <div class="col-sm-5">
                    <a class="card-details" href="#"> More Details </a>
                  </div>
                </div>


              </div>
            </div>

          </div>
        </div>
        <div class="col-md-4">
          <div class="card">
            <div class="card-header">
              <div class="row">


                <div class="col-sm-3">
                  <img class="img-fluid" src="<?php echo asset('master/img/world-wide-web.svg'); ?>" alt="">
                </div>
                <div class="col-sm-6">
                  <h3>Domain Offer <br><span> .com only 499 BDT </span></h3>
                </div>
                <div class="col-sm-3">
                  <h4><span class="dot"></span> Active</h4>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="tldname">
                <h2>.COM</h2>
                <h3>.com is a TLD</h3>
              </div>
              <div class="provider-name">
                <h3>Provider Name:<span> VaneHost</span></h3>
              </div><br>
              <div class="offer-link">
                <a data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo" href="#">Get Your Promo Code</a>

              </div><br>
              <div class="offer-validity">
                <h4>Offer Validity:</h4>
                <div class="offer-time">
                  <div class="row">
                    <div class="col-sm-5">
                      <div class="time-start">


                        <h4>Start Date<br><span>01 July 19</span></h4>
                        <span class="line"></span>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="time-end">


                        <h4>End Date<br><span>01 Nov 19</span></h4>

                      </div>
                    </div>

                  </div>
                  <div class="offer-note">
                    <h4>Note : You can get this offer until end date.</h4>

                  </div>
                </div>

              </div>
              <div class="deal-section">
                <h4>Deal Price:</h4>
                <div class="deal-price">
                  <h2> <span class="currency-symbol">৳</span>4999 <span class="currency">TK</span> </h2>

                </div>
              </div>
              <div class="card-buttons">
                <div class="row">
                  <div class="col-sm-7">
                    <a class="card-order" href="#"> Order Now </a>
                  </div>
                  <div class="col-sm-5">
                    <a class="card-details" href="#"> More Details </a>
                  </div>
                </div>


              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  </div>
  <div class="offer-button">
    <a href="#">More Regular Offers</a>
  </div>
</section>







<?php echo $__env->make('layouts.master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>