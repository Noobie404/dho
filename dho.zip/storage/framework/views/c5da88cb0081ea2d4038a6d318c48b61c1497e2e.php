</div>
</div>
<div class="app-drawer-wrapper">
    <div class="drawer-nav-btn">
        <button type="button" class="hamburger hamburger--elastic is-active">
            <span class="hamburger-box"><span class="hamburger-inner"></span></span></button>
    </div>

</div>
<div class="app-drawer-overlay d-none animated fadeIn"></div>
<script type="text/javascript" src="<?php echo asset('assets/scripts/main.cba69814a806ecc7945a.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('assets/scripts/jquery.dataTables.min.js'); ?>"></script>
<script type="text/javascript" src="<?php echo asset('assets/scripts/dataTables.bootstrap4.min.js'); ?>"></script>
</body>

</html>

<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<!-- <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></!-->
<!-- <script src="https://cdn.datatables.net/1.10.20/js/"></script> -->

<!------------------------------------------------ modal ------------------------------------->

<div id="largeModalsidebar" class="modal fade bd-example-modal-md" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header" style="display: block">
                <h4 class="modal-title" id="myModalLabel" class="text-align: center;">Cox'sbazar SP Office </h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="margin-top: -3rem;">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7427.382623626137!2d91.973954!3d21.441375!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xa3462070485dbcc2!2sPolice%20Super%20Office%2C%20Cox&#39;sbazar!5e0!3m2!1sen!2sus!4v1572779761755!5m2!1sen!2sus" width="1100" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                <hr>
                <h3 align="center">Cox'sbazar Police Super Office</h3>
                <h5 align="center">Saheed Minar Road, Cox'sbazar.</h5>
                <h5 align="center">Contact : 0341-64063</h5>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>