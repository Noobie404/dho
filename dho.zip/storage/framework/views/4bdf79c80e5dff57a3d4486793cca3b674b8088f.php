<?php echo $__env->make('layouts.master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section id="banner-main">
  <div class="container">
    <div class="row">
      <div class="page_heading">
        <?php if(Request::segment(1) == "expired-offer"): ?>
        <h1>Expired Offers</h1><br>
        <?php else: ?>
        <h1><?php echo e($all_offers[0]->offer_cat); ?> Offers</h1><br>
        <?php endif; ?>
        <div class="breadcrumb-section">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('/')); ?>">Home</a></li>
              <?php if(Request::segment(1) == "expired-offer"): ?>
              <li class="breadcrumb-item active" aria-current="page">Expired offers</li>
              <?php else: ?>
              <li class="breadcrumb-item active" aria-current="page"><?php echo e($all_offers[0]->offer_cat); ?> offers</li>
              <?php endif; ?>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</section>
<section id="domain-offers">
  <div class="row">
    <div class="col-md-12">
      <div class="domain-offers-header">
        <h2>Filter Your Choice</h2>
      </div>
      <div class="row">
        <div class="col-md-3">
        </div>
        <div class="col-md-6">
          <ul id="tabsJustified" class="nav nav-tabs">
            <li class="nav-item">
              <a class="show active" data-target="#all-exclusive-offers" data-toggle="tab" href="">All Offers</a>
            </li>
            <li class="nav-item">
              <a id="Domain-exclusive" data-target="#domain-exclusive-offers" data-toggle="tab" href="">Domain</a>
            </li>
            <li class="nav-item">
              <a id="Hosting-exclusive" data-target="#hosting-exclusive-offers" data-toggle="tab" href="">Hosting</a>
            </li>
            <li class="nav-item">
              <a id="Combo-exclusive" data-target="#combo-exclusive-offers" data-toggle="tab" href="">Combo</a>
            </li>
            <li class="nav-item">
              <a id="Web-Server-exclusive" data-target="#web-exclusive-offers" data-toggle="tab" href="">Web-Server</a>
            </li>
          </ul>
        </div>
        <div class="col-md-3">
        </div>
      </div>
      <div id="tabsJustifiedContent" class="tab-content">
        <div id="all-exclusive-offers" class="tab-pane fade  active show">
          <?php echo $__env->make('offers.all-exclusive-offers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div id="domain-exclusive-offers" class="tab-pane fade">
          <?php echo $__env->make('offers.all-exclusive-domain-offers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div id="hosting-exclusive-offers" class="tab-pane fade">
          <?php echo $__env->make('offers.all-exclusive-hosting-offers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div id="combo-exclusive-offers" class="tab-pane fade">
          <?php echo $__env->make('offers.all-exclusive-combo-offers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div id="web-exclusive-offers" class="tab-pane fade">
          <?php echo $__env->make('offers.all-exclusive-web-offers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
      </div>
    </div>
</section>
<?php echo $__env->make('layouts.master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>