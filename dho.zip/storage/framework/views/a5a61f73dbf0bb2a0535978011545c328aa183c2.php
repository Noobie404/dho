<?php echo $__env->make('layouts.master.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section id="banner-main">
  <div class="container">
    <div class="row">
      <div class="page_heading">
        <?php 
        $title2 = explode('-', Request::segment(1));
        $title = ucfirst($title2[0]);
        ?>
        <h1><?php echo e($title); ?> Offers</h1><br>
        <div class="breadcrumb-section">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('/')); ?>">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page"><?php echo e($title); ?> offers</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</section>
<section id="domain-offers">
  <div class="row">
    <div class="col-md-12">
      <div class="domain-offers-header">
        <h2>Filter Your Choice</h2>
      </div>
      <div class="row">
        <div class="col-md-3">
        </div>
        <div class="col-md-6">
          <ul id="tabsJustified" class="nav nav-tabs">
            <li class="nav-item">
              <a class="show active" data-target="#all-<?php echo e($title); ?>-offers" data-toggle="tab" href="">All Offers</a>
            </li>
            <li class="nav-item">
              <a id="exclusive-<?php echo e($title); ?>" data-target="#exclusive-<?php echo e($title); ?>-offers" data-toggle="tab" href="">Exclusive Offers</a>
            </li>
            <li class="nav-item">
              <a id="special-<?php echo e($title); ?>" data-target="#special-<?php echo e($title); ?>-offers" data-toggle="tab" href="">Special offers</a>
            </li>
            <li class="nav-item">
              <a id="regular-<?php echo e($title); ?>" data-target="#regular-<?php echo e($title); ?>-offers" data-toggle="tab" href="">Regular Offers</a>
            </li>
          </ul>
        </div>
        <div class="col-md-3">
        </div>
      </div>
      <div id="tabsJustifiedContent" class="tab-content">
        <div id="all-<?php echo e($title); ?>-offers" class="tab-pane fade  active show">
          <?php echo $__env->make('offers.all-domain-offers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div id="exclusive-<?php echo e($title); ?>-offers" class="tab-pane fade">
          <?php echo $__env->make('offers.exclusive-domain-offers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div id="special-<?php echo e($title); ?>-offers" class="tab-pane fade">
          <?php echo $__env->make('offers.special-domain-offers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div id="regular-<?php echo e($title); ?>-offers" class="tab-pane fade">
          <?php echo $__env->make('offers.regular-domain-offers', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
      </div>
    </div>
</section>
<?php echo $__env->make('layouts.master.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>