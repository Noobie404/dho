Hi {{$data['name']}},<br>
Welcome to Ticket Gripe. <br>
You have purchased ticket for the event <strong>{{$data['event_title']}}</strong>.<br>
You can download or print your ticket from this link <a href="https://ticketgripe.com/ticket-view/{{$data['tran_id']}}/{{$data['event_id']}}/{{$data['ticket_id']}}/{{$data['random_number']}}">https://ticketgripe.com/ticket-view/{{$data['tran_id']}}/{{$data['event_id']}}/{{$data['ticket_id']}}/{{$data['random_number']}}</a> <br>
After the event expires, you can no longer access this ticket. <br>
<br> For further queries email at: <br> support@ticketgripe.com
<br><br>
Regards, <br>
Team Ticket Gripe<br>
Website: www.ticketgripe.com